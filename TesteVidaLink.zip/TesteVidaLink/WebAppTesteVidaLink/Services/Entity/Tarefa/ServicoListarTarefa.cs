﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using WebAppTesteVidaLink.Models;

namespace WebAppTesteVidaLink.Services.Entity.Tarefa
{
	public class ServicoListarTarefa : BaseService, IDisposable
	{
		public void Dispose()
		{
			
		}

		public List<TAREFA> ObterLista(String textoPesquisa)
		{
			List<TAREFA> lista;

			try
			{
				using (DatabaseContext db = new DatabaseContext())
				{
					String sql = "SELECT TOP 5 ID_TAREFA, TITULO_TAREFA, DESC_TAREFA, DT_EXEC_TAREFA FROM TAREFA";

					if (textoPesquisa != null && textoPesquisa.Trim().Length > 0)
					{
						sql += " WHERE ";
						sql += " TITULO_TAREFA LIKE '%" + textoPesquisa.Trim() + "%'";
						sql += " OR DESC_TAREFA LIKE '%" + textoPesquisa.Trim() + "%'";
					}

					sql += " ORDER BY DT_EXEC_TAREFA DESC";



					lista = db.TAREFA.SqlQuery(sql).ToList();

					if (lista.Count == 0)
					{
						base._sucesso = false;
						base._mensagem = String.Format("Nenhuma tarefa foi encontrada.");
					}
					else
					{
						base._sucesso = true;
						base._mensagem = String.Format("Foram encontradas {0} tarefas.", lista.Count );
					}

				}
			}
			catch
			{
				base._sucesso = false;
				base._mensagem = "Ocorreu um erro durante a consulta das tarefas.";

				lista = new List<TAREFA>();
			}

			return lista;
		}

	}
}