﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using WebAppTesteVidaLink.Models;

namespace WebAppTesteVidaLink.Services.Entity.Tarefa
{
	public class ServicoExcluirTarefa : BaseService,  IDisposable
	{
		public void Dispose()
		{

		}


		public Boolean ExcluirItem(long idTarefa)
		{

			try
			{
				using (DatabaseContext db = new DatabaseContext())
				{
					TAREFA item = db.TAREFA.Find(idTarefa);

					if (item == null)
					{
						base._sucesso = true;
						base._mensagem = "Tarefa não encontrada.";
					}
					else
					{
						db.TAREFA.Remove(item);

						db.SaveChanges();

						base._sucesso = true;
						base._mensagem = "Tarefa excluida com sucesso.";
					}
				}
			}
			catch
			{
				base._sucesso = false;
				base._mensagem = "Ocorreu um erro durante a exclusao da tarefa.";

			}

			return base._sucesso;
		}


	}
}