﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using WebAppTesteVidaLink.Models;

namespace WebAppTesteVidaLink.Services.Entity.Tarefa
{
	public class ServicoIncluirTarefa : BaseService, IDisposable
	{
		public void Dispose()
		{

		}

		public Boolean IncluirItem(TAREFA item)
		{
			try
			{
				using (DatabaseContext db = new DatabaseContext())
				{
					db.TAREFA.Add(item);

					db.SaveChanges();

					base._sucesso = true;
					base._mensagem = "Tarefa incluida com sucesso.";
				}
			}
			catch
			{
				base._sucesso = false;
				base._mensagem = "Ocorreu um erro durante a inclusão da tarefa. Verifique os dados digitados.";
			}

			return base._sucesso;
		}

	}
}