﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using WebAppTesteVidaLink.Models;

namespace WebAppTesteVidaLink.Services.Entity.Tarefa
{
	public class ServicoConsultarTarefa : BaseService, IDisposable
	{
		public void Dispose()
		{

		}


		public TAREFA ObterItem(long idTarefa)
		{
			TAREFA item;

			try
			{
				using (DatabaseContext db = new DatabaseContext())
				{
					item = db.TAREFA.Find(idTarefa);

					if (item == null)
					{
						base._sucesso = true;
						base._mensagem = "Tarefa nao encontrada.";
					}
					else
					{
						base._sucesso = true;
						base._mensagem = "Tarefa encontrada com sucesso.";
					}
				}
			}
			catch
			{
				base._sucesso = false;
				base._mensagem = "Ocorreu um erro durante a consulta da tarefa.";

				item = null;
			}

			return item;
		}
	}
}