﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;


using WebAppTesteVidaLink.Models;

namespace WebAppTesteVidaLink.Services.Entity.Tarefa
{
	public class ServicoAlterarTarefa : BaseService, IDisposable
	{
		public void Dispose()
		{

		}


		public Boolean AlterarItem(TAREFA itemAlterado)
		{
			try
			{
				using (DatabaseContext db = new DatabaseContext())
				{
					TAREFA item = db.TAREFA.Find(itemAlterado.ID_TAREFA);

					if (item == null)
					{
						base._sucesso = true;
						base._mensagem = "Tarefa nao encontrada.";
					}
					else
					{
						item.TITULO_TAREFA = itemAlterado.TITULO_TAREFA;
						item.DESC_TAREFA = itemAlterado.DESC_TAREFA;
						item.DT_EXEC_TAREFA = itemAlterado.DT_EXEC_TAREFA;

						db.Entry(item).State = EntityState.Modified;
						
						db.SaveChanges();

						base._sucesso = true;
						base._mensagem = "Tarefa alterada com sucesso.";
					}
				}
			}
			catch
			{
				base._sucesso = false;
				base._mensagem = "Ocorreu um erro durante a alteração da tarefa. Verifique os dados digitados.";
			}

			return base._sucesso;
		}


	}
}