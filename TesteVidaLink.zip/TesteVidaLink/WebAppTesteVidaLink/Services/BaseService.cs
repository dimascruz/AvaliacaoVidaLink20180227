﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebAppTesteVidaLink.Services
{
	public class BaseService
	{
		protected Boolean _sucesso;
		protected String _mensagem;


		public String Mensagem
		{
			get
			{
				return this._mensagem;
			}
		}


		public Boolean Sucesso
		{
			get
			{
				return this._sucesso;
			}
		}

	}
}