﻿===================================================================
Instruções para avaliar a aplicação WebAppTestVidaLink
===================================================================

1. Criar um banco de dados chamado Teste Vida Link (utilizar SQL Server )

2. Criar um usuário chamado vidalink. A senha desse usuário deve ser y00bcda
User ID=vidalink
Password=y00bcda

3. Descompactar arquivo TesteVidaLink.zip em uma pasta

4. Abrir solução WebAppTesteVidaLink.sln utilizando o Visual Studio 2017

5. Executar o script SQL_Script_Schema para criar as tabelas. Esse script esta dentro da solução no nível principal

6. Executar o script SQL_Script_Data para carregar os usuários. . Esse script esta dentro da solução no nível principal

7. Executar a aplicação

8. Entrar com o usuário e senha abaixo
Usuario: testuser@test.com
Senha: @TestUser001


