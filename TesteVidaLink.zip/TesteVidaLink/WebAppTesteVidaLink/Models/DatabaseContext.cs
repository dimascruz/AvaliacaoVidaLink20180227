namespace WebAppTesteVidaLink.Models
{
	using System;
	using System.Data.Entity;
	using System.ComponentModel.DataAnnotations.Schema;
	using System.Linq;

	public partial class DatabaseContext : DbContext
	{
		public DatabaseContext()
			: base("name=DefaultConnection")
		{
		}

		public virtual DbSet<TAREFA> TAREFA { get; set; }

		protected override void OnModelCreating(DbModelBuilder modelBuilder)
		{
			modelBuilder.Entity<TAREFA>()
				.Property(e => e.TITULO_TAREFA)
				.IsUnicode(false);

			modelBuilder.Entity<TAREFA>()
				.Property(e => e.DESC_TAREFA)
				.IsUnicode(false);
		}
	}
}
