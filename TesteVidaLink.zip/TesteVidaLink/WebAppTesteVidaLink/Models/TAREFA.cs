namespace WebAppTesteVidaLink.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("TAREFA")]
    public partial class TAREFA
    {
        [Key]
		[Display(Name = "ID Tarefa")]
		public long ID_TAREFA { get; set; }

        [Required]
        [StringLength(30)]
		[Display(Name = "T�tulo da Tarefa")]
		public string TITULO_TAREFA { get; set; }

        [Required]
        [StringLength(100)]
		[Display(Name = "Descri��o")]
		public string DESC_TAREFA { get; set; }

		[Required]
		[Display(Name = "Data de Execu��o")]
		[DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
		public DateTime DT_EXEC_TAREFA { get; set; }
    }
}
