﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using WebAppTesteVidaLink.Models;

using WebAppTesteVidaLink.Services.Entity.Tarefa;

namespace WebAppTesteVidaLink.Controllers
{
	public class HomeController : BaseController
	{
		public ActionResult Index()
		{
			ActionResult result;

			if (this.Request.IsAuthenticated)
			{				
				result = View();
			}
			else
			{
				result = this.RedirectToAction("Login", "Account");
			}

			return result;
		}
	}
}