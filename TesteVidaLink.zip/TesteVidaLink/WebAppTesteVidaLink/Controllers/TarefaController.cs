﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using WebAppTesteVidaLink.Models;

using WebAppTesteVidaLink.Services.Entity.Tarefa;

namespace WebAppTesteVidaLink.Controllers
{
	[Authorize]
    public class TarefaController : BaseController
    {
        // GET: Tarefa
        public ActionResult Index()
        {
            return View();
        }


		[HttpGet]
		public ActionResult AlterarTarefa(long idTarefa)
		{
			TAREFA item = base.ConsultarItemTarefa(idTarefa);

			Boolean readOnly;

			if (item.DT_EXEC_TAREFA > DateTime.Today)
			{
				readOnly = false;
			}
			else
			{
				readOnly = true;

				this.ViewBag.Mensagem = "Somente tarefas com data de execução superior a de hoje podem ser editadas.";
			}


			this.ViewBag.ReadOnly = readOnly;


			return PartialView(item);
		}


		[HttpPost]
		public ActionResult AlterarTarefa(TAREFA item)
		{
			ActionResult result;

			if (this.ModelState.IsValid)
			{
				using (ServicoAlterarTarefa servico = new ServicoAlterarTarefa())
				{
					Boolean sucesso = servico.AlterarItem(item);

					if (sucesso)
					{
						List<TAREFA> lista = base.ConsultarListaTarefa();

						result = PartialView("ListarTarefa", lista);
					}
					else
					{
						item = base.ConsultarItemTarefa(item.ID_TAREFA);

						result = PartialView(item);
					}

					this.ViewBag.Mensagem = servico.Mensagem;
				}
			}
			else
			{
				result = PartialView(item);
			}


			return result;
		}


		[HttpGet]
		public ActionResult ExcluirTarefa(long idTarefa)
		{
			TAREFA item = base.ConsultarItemTarefa(idTarefa);

			return PartialView(item);
		}


		[HttpPost]
		public ActionResult ExcluirTarefaPost(long idTarefa)
		{
			ActionResult result;

			using (ServicoExcluirTarefa servico = new ServicoExcluirTarefa())
			{
				Boolean sucesso = servico.ExcluirItem(idTarefa);

				if (sucesso)
				{
					List<TAREFA> lista = base.ConsultarListaTarefa();

					result = PartialView("ListarTarefa", lista);
				}
				else
				{
					TAREFA item = base.ConsultarItemTarefa(idTarefa);

					result = PartialView("ExcluirTarefa", item);
				}

				this.ViewBag.Mensagem = servico.Mensagem;
			}

			return result;
		}


		[HttpGet]
		public ActionResult IncluirTarefa()
		{
			return PartialView();
		}


		[HttpPost]
		public ActionResult IncluirTarefa(TAREFA item)
		{
			ActionResult result;


			if (this.ModelState.IsValid)
			{
				using (ServicoIncluirTarefa servico = new ServicoIncluirTarefa())
				{
					Boolean sucesso = servico.IncluirItem(item);

					if (sucesso)
					{
						List<TAREFA> lista = base.ConsultarListaTarefa();

						result = PartialView("ListarTarefa", lista);
					}
					else
					{
						result = PartialView(item);
					}

					this.ViewBag.Mensagem = servico.Mensagem;
				}

			}
			else
			{
				result = PartialView(item);
			}


			return result;
		}


		[HttpGet]
		public ActionResult ListarTarefa()
		{
			List<TAREFA> lista = base.ConsultarListaTarefa();

			return PartialView(lista);
		}



		[HttpGet]
		public ActionResult PesquisarTarefa(String textoPesquisa)
		{
			List<TAREFA> lista = base.ConsultarListaTarefa(textoPesquisa);

			return PartialView("ListarTarefa", lista);
		}


	}
}