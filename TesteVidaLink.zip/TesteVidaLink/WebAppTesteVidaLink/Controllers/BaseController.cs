﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using WebAppTesteVidaLink.Models;

using WebAppTesteVidaLink.Services.Entity.Tarefa;


namespace WebAppTesteVidaLink.Controllers
{
    public class BaseController : Controller
    {

		protected List<TAREFA> ConsultarListaTarefa()
		{
			return this.ConsultarListaTarefa(null);
		}

		protected List<TAREFA> ConsultarListaTarefa(String textoPesquisa)
		{
			using (ServicoListarTarefa servico = new ServicoListarTarefa())
			{
				List<TAREFA> lista = servico.ObterLista(textoPesquisa);

				if (servico.Sucesso)
				{
					this.ViewBag.Mensagem = null;
				}
				else
				{
					this.ViewBag.Mensagem = servico.Mensagem;
				}

				return lista;
			}
		}


		protected TAREFA ConsultarItemTarefa(long idTarefa)
		{
			using (ServicoConsultarTarefa servico = new ServicoConsultarTarefa())
			{
				TAREFA item = servico.ObterItem(idTarefa);

				return item;
			}
		}


	}
}